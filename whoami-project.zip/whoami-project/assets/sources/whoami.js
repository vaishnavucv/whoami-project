pref("privacy.firstparty.isolate", true);
pref("privacy.resistFİngerprinting", true);
pref("privacy.trackingprotection.fingerprinting.enabled", true);
pref("privacy.trackingprotection.cryptomining.enabled", true);
pref("privacy.trackingprotection.enabled", true);
pref("browser.send_pings", false);
pref("browser.urlbar.spectulativeConnect.enabled", false);